package java;

public enum StatusPedido {
    AGUARDANDO, APROVADO, ENTREGUE;
}
